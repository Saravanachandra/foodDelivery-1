package freaktemplate.Getset;

/**
 * Created by Redixbit 2 on 04-10-2016.
 */
public class placeordergetset {

    private String status;
    private String Msg;

    public String getMsg() {
        return Msg;
    }

    public void setMsg(String msg) {
        Msg = msg;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
