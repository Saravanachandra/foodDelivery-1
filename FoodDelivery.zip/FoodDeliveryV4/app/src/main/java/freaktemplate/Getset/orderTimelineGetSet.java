package freaktemplate.Getset;

/**
 * Created by RedixbitUser on 3/23/2018.
 */

public class orderTimelineGetSet {
    private String order_date_time;

    public String getOrder_date_time() {
        return order_date_time;
    }

    public void setOrder_date_time(String order_date_time) {
        this.order_date_time = order_date_time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private String status;
}
