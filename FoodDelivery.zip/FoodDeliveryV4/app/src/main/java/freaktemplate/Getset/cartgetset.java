package freaktemplate.Getset;

/**
 * Created by Redixbit 2 on 17-09-2016.
 */
public class cartgetset {

     private String resid;
    private String menuid;
    private String foodid;
    private String foodname;
    private String foodprice;
    private String fooddesc;
    private String restcurrency;
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getResid() {
        return resid;
    }

    public void setResid(String resid) {
        this.resid = resid;
    }

    public String getMenuid() {
        return menuid;
    }

    public void setMenuid(String menuid) {
        this.menuid = menuid;
    }

    public String getFoodid() {
        return foodid;
    }

    public void setFoodid(String foodid) {
        this.foodid = foodid;
    }

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public String getFoodprice() {
        return foodprice;
    }

    public void setFoodprice(String foodprice) {
        this.foodprice = foodprice;
    }

    public String getFooddesc() {
        return fooddesc;
    }

    public void setFooddesc(String fooddesc) {
        this.fooddesc = fooddesc;
    }

    public String getRestcurrency() {
        return restcurrency;
    }

    public void setRestcurrency(String restcurrency) {
        this.restcurrency = restcurrency;
    }
}
