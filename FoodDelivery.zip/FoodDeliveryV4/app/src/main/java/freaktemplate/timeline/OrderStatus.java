package freaktemplate.timeline;

/**
 * Created by RedixbitUser on 3/22/2018.
 */

public enum OrderStatus {
    COMPLETED,
    ACTIVE,
    INACTIVE;
}