package freaktemplate.Adapter;

import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
/**
 * Created by Redixbit 2 on 14-10-2016.
 */

public class ListViewHolderCart {
    //cart page
    public TextView txt_name1;
    public TextView txt_name;
    public TextView txt_desc;
    public TextView txt_quantity;
    public TextView txt_basic_price;
    public ImageButton btn_minus1;
    public ImageButton btn_plus;
    public TextView txt_totalprice;
    public EditText edTextQuantity;

}
